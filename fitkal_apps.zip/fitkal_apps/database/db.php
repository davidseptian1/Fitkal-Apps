<?php
class Database {
    private $host = "localhost"; 
    private $dbname = "fitkal_db";
    private $username = "root";  // Ubah jika pakai username lain
    private $password = "";      // Ubah jika pakai password MySQL

    public $conn;

    public function __construct() {
        try {
            $this->conn = new PDO("mysql:host=$this->host;dbname=$this->dbname", $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Koneksi Gagal: " . $e->getMessage());
        }
    }
}
?>
