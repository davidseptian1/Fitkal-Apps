<?php
require_once "database/db.php"; // Panggil koneksi database

session_start();

// Inisialisasi keranjang dan total kalori jika belum ada
if (!isset($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = [];
    $_SESSION['total_kalori'] = 0;
}

$errors = [];

// Jika form disubmit untuk memilih makanan
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['pilih'])) {
    $makanan_id = $_POST['makanan_id'];
    // Cek jika 'kategori' dan 'status_ekonomi' ada di POST
    $kategori = isset($_POST['kategori']) ? $_POST['kategori'] : '';
$status_ekonomi = isset($_POST['status_ekonomi']) ? $_POST['status_ekonomi'] : '';


    // Ambil data makanan dari database
    $db = new Database();
    $conn = $db->conn;
    $stmt = $conn->prepare("SELECT * FROM makanan WHERE id = :id");
    $stmt->bindParam(":id", $makanan_id);
    $stmt->execute();
    $makanan = $stmt->fetch(PDO::FETCH_ASSOC); // Ambil satu baris data

    // Menambahkan makanan ke keranjang jika ditemukan
    if ($makanan) {
        // Cek jika kalori melebihi batas
        if ($_SESSION['total_kalori'] + $makanan['kalori'] <= 2000) {  // Misalnya batas kalori harian 2000
            $_SESSION['keranjang'][] = $makanan;
            $_SESSION['total_kalori'] += $makanan['kalori'];
        } else {
            $errors[] = "Kalori sudah melebihi batas harian kamu!";
        }
    }
}

// Simpan makanan ke dalam record_makanan ketika tombol "Simpan Makanan Hari Ini" diklik
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['simpan'])) {
    $selected_items = $_POST['selected_items'];  // Mengambil item yang dicentang untuk disimpan
    $db = new Database();
    $conn = $db->conn;

    // Cek apakah ada makanan yang dipilih
    if (!empty($selected_items)) {
        foreach ($selected_items as $makanan_id) {
            // Simpan record makanan dengan tanggal sekarang
            $stmt = $conn->prepare("INSERT INTO record_makanan (user_id, makanan_id, tanggal) VALUES (:user_id, :makanan_id, :tanggal)");
            $stmt->bindParam(":user_id", $_SESSION['user_id']);
            $stmt->bindParam(":makanan_id", $makanan_id);
            $stmt->bindParam(":tanggal", date('Y-m-d'));
            $stmt->execute();
        }

        // Redirect ke halaman cek record makanan setelah berhasil disimpan
        header("Location: cek_recordmakanan.php"); // Ganti dengan halaman cek record makanan
        exit;
    } else {
        $errors[] = "Tidak ada makanan yang dipilih untuk disimpan.";
    }
}

// Hapus makanan dari keranjang
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['hapus'])) {
    $makanan_id = $_POST['makanan_id'];
    
    // Hapus makanan dari keranjang
    foreach ($_SESSION['keranjang'] as $index => $item) {
        if ($item['id'] == $makanan_id) {
            $_SESSION['total_kalori'] -= $item['kalori'];
            unset($_SESSION['keranjang'][$index]);
            break;
        }
    }
    // Reindex array setelah dihapus
    $_SESSION['keranjang'] = array_values($_SESSION['keranjang']);
}

// Hapus semua makanan dari keranjang
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['hapus_semua'])) {
    $_SESSION['keranjang'] = [];
    $_SESSION['total_kalori'] = 0;
}

// Tambahkan pengecekan apakah kategori dan status_ekonomi sudah diset
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['pilih']) && !isset($_POST['simpan'])) {
    // Cek apakah 'kategori' dan 'status_ekonomi' ada di POST
    if (isset($_POST['kategori']) && isset($_POST['status_ekonomi'])) {
        $kategori = $_POST['kategori'];
        $status_ekonomi = $_POST['status_ekonomi'];

        $db = new Database();
        $conn = $db->conn;

        $stmt = $conn->prepare("SELECT * FROM makanan WHERE kategori = :kategori AND status_ekonomi = :status_ekonomi");
        $stmt->bindParam(":kategori", $kategori);
        $stmt->bindParam(":status_ekonomi", $status_ekonomi);
        $stmt->execute();

        $makanan = $stmt->fetchAll(PDO::FETCH_ASSOC); // Ambil semua data dalam bentuk array
    } else {
        // Jika kategori atau status_ekonomi belum dipilih, tampilkan pesan atau tangani dengan cara lain
        $errors[] = "Pilih kategori dan status ekonomi terlebih dahulu.";
    }
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekomendasi Makanan - Fitkal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Favicons -->
    <link href="assets/img/logofitkal.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Inter:wght@100;200;300;400;500;600;700;800;900&family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet">
    <style>
        .makanan-item {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            margin-bottom: 20px;
            transition: transform 0.2s ease-in-out;
        }

        .makanan-item:hover {
            transform: scale(1.05);
        }

        .makanan-item img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .makanan-item h5 {
            margin-top: 10px;
            font-size: 1.1rem;
        }

        .makanan-item .btn {
            margin-top: 10px;
        }

        .makanan-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h2>Rekomendasi Makanan Sehat</h2>
        
        <form action="fitur_makanan.php" method="POST" class="mb-4">
            <div class="mb-3">
                <label for="kategori" class="form-label">Pilih Kategori Makanan:</label>
                <select name="kategori" id="kategori" class="form-select" required>
                    <option value="sayur">Sayur</option>
                    <option value="makanan_ringan">Makanan Ringan</option>
                    <option value="makanan_berat">Makanan Berat</option>
                    <option value="jus_buah">Jus Buah</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="status_ekonomi" class="form-label">Pilih Status Ekonomi:</label>
                <select name="status_ekonomi" id="status_ekonomi" class="form-select" required>
                    <option value="hemat">Mode Hemat</option>
                    <option value="gajian">Mode Gajian</option>
                    <option value="sultan">Mode Sultan</option>
                    <option value="anak_kuliahan">Mode Anak Kuliahan</option>
                    <option value="anak_sekolahan">Mode Anak Sekolah</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Dapatkan Rekomendasi</button>
        </form>

        <h3>Keranjang (Total Kalori: <?php echo $_SESSION['total_kalori']; ?> Kcal)</h3>
        <?php if ($errors): ?>
            <div class="alert alert-danger">
                <?php echo implode('<br>', $errors); ?>
            </div>
        <?php endif; ?>

        <ul class="list-group mb-4">
            <?php foreach ($_SESSION['keranjang'] as $item): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <img src="images/<?php echo $item['gambar']; ?>" alt="<?php echo $item['nama']; ?>" class="img-thumbnail me-3">
                    <div>
                        <strong><?php echo $item['nama']; ?></strong><br>
                        Kalori: <?php echo $item['kalori']; ?> Kcal
                    </div>
                    <form action="fitur_makanan.php" method="POST" class="ms-3">
                        <input type="hidden" name="makanan_id" value="<?php echo $item['id']; ?>">
                        <button type="submit" name="hapus" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>

        <!-- Tombol Hapus Semua Keranjang -->
        <form action="fitur_makanan.php" method="POST" class="mb-4">
            <button type="submit" name="hapus_semua" class="btn btn-warning">Hapus Semua Makanan di Keranjang</button>
        </form>

        <form action="fitur_makanan.php" method="POST" class="mb-4">
            <label>Pilih Makanan yang Ingin Disimpan:</label><br>
            <?php foreach ($_SESSION['keranjang'] as $item): ?>
                <div class="form-check">
                    <input type="checkbox" name="selected_items[]" value="<?php echo $item['id']; ?>" class="form-check-input">
                    <label class="form-check-label">
                        <strong><?php echo $item['nama']; ?></strong> (Kalori: <?php echo $item['kalori']; ?>)
                    </label>
                </div>
            <?php endforeach; ?>
            <br>
            <button type="submit" name="simpan" class="btn btn-success">Simpan Makanan Hari Ini</button>
        </form>

        <?php if (isset($makanan) && !empty($makanan)): ?>
            <h3>Rekomendasi Makanan untuk Kategori "<?php echo htmlspecialchars($kategori); ?>" dengan Status Ekonomi "<?php echo htmlspecialchars($status_ekonomi); ?>"</h3>
            <div class="makanan-container">
                <?php foreach ($makanan as $item): ?>
                    <div class="makanan-item text-center">
                        <img src="images/<?php echo htmlspecialchars($item['gambar']); ?>" alt="<?php echo htmlspecialchars($item['nama']); ?>" class="img-fluid">
                        <h5><?php echo htmlspecialchars($item['nama']); ?></h5>
                        <p>Kalori: <?php echo $item['kalori']; ?> Kcal</p>
                        <p>Protein: <?php echo $item['protein']; ?>g</p>
                        <p>Lemak: <?php echo $item['lemak']; ?>g</p>
                        <p>Karbohidrat: <?php echo $item['karbo']; ?>g</p>
                        <form action="fitur_makanan.php" method="POST">
                            <input type="hidden" name="makanan_id" value="<?php echo $item['id']; ?>">
                            <button type="submit" name="pilih" class="btn btn-primary btn-sm">Pilih</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
<?php

require_once "sisipkan/footer.php";
?>
</html>
